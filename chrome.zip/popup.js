/* eslint-env browser */

window.endpoint = 'https://nbox.notif.me';

$('body').append(`<script type="text/javascript" src="${window.endpoint}/popup.js"></script>`);
